module WordCounter {
}